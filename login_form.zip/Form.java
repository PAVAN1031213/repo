package project;

public class Form {

	public static void main(String[] args) {
		System.out.println("testing....");
		MyWindow w= new MyWindow();
	}	
}
